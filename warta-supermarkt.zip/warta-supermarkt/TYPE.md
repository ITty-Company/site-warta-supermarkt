# TYPE — Warta Supermarkt (Waalwijk)

Стиль: «★ ГЛАВНЫЙ СТИЛЬ» DESIGN_STANDARD — тонкий геометрический гротеск, огромный строчный заголовок с точкой, плотный межстрочный. Никакого капса-постера.

## Пара (3 начертания всего)
| Роль | Семейство | Начертания | Зачем |
|---|---|---|---|
| Дисплей (h1–h3, чип, цифры в стеклянных плашках) | **Sora** | 300 | Геометрия с широкими круглыми формами и чуть «технологичными» терминалами — отличается от Urbanist (scena-piekna), даёт премиальный кинематографичный тон; в 300 на тёмном фоне выглядит дорого. |
| Текст (абзацы, навигация, кнопки, подписи) | **Figtree** | 400, 500 | Тёплый, очень читаемый на телефоне; 500 — только кнопки/навигация/метки. |

Не повторяет журнал (`journal/fonts.md`): Playfair/Pinyon/Inter/Space Mono, Bricolage/Great Vibes, Urbanist — не использованы.

## Польская диакритика — проверено
Google Fonts CSS2 API (17.11.2026) отдаёт для обоих семейств подмножество `latin-ext` (U+0100–02BA) → **ą ę ł ń ś ź ż** + `latin` (U+0000–00FF) → **ó**. Также голландские ë/ï/é. Тестовая строка для скриншота: `Zażółć gęślą jaźń · Poolse producten in Waalwijk.`

## Подключение
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500&family=Sora:wght@300&display=swap" rel="stylesheet">
```
(Браузер сам подтянет latin-ext по unicode-range; `&subset` не нужен.) В `<html lang="nl">` / `lang="pl"` для PL-версии.

```css
:root{
  --font-display: "Sora", ui-sans-serif, system-ui, sans-serif;
  --font-body: "Figtree", ui-sans-serif, system-ui, sans-serif;
}
```

## Шкала
| Токен | Размер | Начертание | line-height | letter-spacing |
|---|---|---|---|---|
| h1 (hero, 3–4 строки, строчные + точка) | `clamp(3rem, 1.6rem + 6.4vw, 8.5rem)` | Sora 300 | 0.98 | -0.045em |
| h2 (секции) | `clamp(2.25rem, 1.4rem + 3.6vw, 5rem)` | Sora 300 | 1.02 | -0.035em |
| h3 (карточки, группы товаров) | `clamp(1.5rem, 1.2rem + 1.2vw, 2.25rem)` | Sora 300 | 1.12 | -0.02em |
| Цифра в стеклянной плашке | `clamp(1.75rem, 1.3rem + 1.6vw, 2.75rem)` | Sora 300, `font-variant-numeric: tabular-nums` | 1 | -0.02em |
| lead (подзаголовок hero) | `clamp(1.125rem, 1rem + 0.5vw, 1.375rem)` | Figtree 400 | 1.5 | 0 |
| body | `clamp(17px, 16px + 0.25vw, 19px)` | Figtree 400 | 1.6 | 0 |
| nav / кнопки | 15–16px | Figtree 500 | 1 | 0.01em |
| чип над заголовком / мелкие метки | 13–14px | Figtree 500 | 1.2 | 0.04em (строчные, НЕ капс) |
| подпись «Voorbeeldbeeld», сноски | 12–13px | Figtree 400 | 1.4 | 0.02em |

## Правила
- Заголовки строчными («poolse smaken, om de hoek.»), короткая фраза с точкой; польское слово в заголовке допустимо тем же шрифтом (без рукописного акцента).
- Капс не используется нигде, кроме аббревиатур (BV, NL/PL в переключателе).
- Максимальная ширина абзаца 60ch; h1 — до ~12ch на строку, `text-wrap: balance`.
- Заголовки выезжают по словам: следить, чтобы перенос не разрывал слово с диакритикой (`hyphens: manual`).
- На тёмном фоне Sora 300 не опускать ниже 24px — для мелких размеров брать Figtree.
