# STORY — Warta Supermarkt (Waalwijk)

Роль: story-architect · вход: BRIEF.md, PALETTE.md («Warta po zmroku»), TYPE.md (Sora 300 + Figtree), DESIGN_STANDARD ★ ГЛАВНЫЙ СТИЛЬ + §9 + §10 + §11, эталон структуры `sites/scena-piekna`.
Дата: 17.11.2026

---

## 0. Главная идея

**ОДИН ОБЪЕКТ: плетёная корзина (koszyk) с льняным полотенцем.**
Почему корзина, а не конкретный продукт: ассортимент Warta НЕ подтверждён (BRIEF → UNKNOWN). Корзина — нейтральный, универсальный символ продуктового магазина и одновременно очень «польский» образ (корзинка с полотенцем, с которой идут за покупками / на рынок / на święconka). Она позволяет показать «мир польского магазина», не утверждая, что именно продаётся в Waalwijk.

**Сюжет:** корзина стоит на тёмном дубовом прилавке ночью у реки Warta (название магазина = польская река) под одним красным светом. Она полная → опустошается → по шагам наполняется заново (полотенце, хлеб, банка, колбаса и бутылка молока) → снова полная и укрыта → стоит на пороге на мокрой ночной улице «om de hoek» → контакт.

**ПРАВИЛО ЧЕСТНОСТИ (обязательно для copywriter и builder):**
- Все предметы в корзине — **sfeerbeeld**. Под каждым кадром с продуктами мелкая подпись (12–13px Figtree, `--mist`):
  NL `Sfeerbeeld — geen weergave van het actuele assortiment.` / PL `Zdjęcie poglądowe — nie przedstawia aktualnego asortymentu.`
- Тексты глав о хлебе/банках/колбасе пишутся как **о польской кухне и привычках вообще** («in Poolse keukens…», «voor veel Polen…»), а не «bij Warta vind je…». Любое утверждение о наличии — только с меткой `[TE BEVESTIGEN]`.
- Никаких брендов, цен, звёзд, часов (`[OPENINGSTIJDEN TE BEVESTIGEN]`), email, Instagram, KvK, истории/года открытия.
- Подтверждённые факты, которые МОЖНО ставить в стеклянные плашки: `Stationsstraat 126`, `5141 GH Waalwijk`, `0416 203 437`, `Facebook`, «Poolse supermarkt» (с оговоркой: профиль из данных лида — ставим, но без деталей), «Warta = Poolse rivier» (общеизвестный факт о названии).

**Якорь всех кадров (визуальная склейка):** одна и та же камера (3/4 спереди, 25° сверху, 50mm), тот же тёмный дубовый прилавок, корзина в правой половине кадра (центр ≈ 64% по X, 55% по Y, ~45% высоты кадра), слева 40% пустой тёмной зоны, ivory-ключевой свет сверху слева, ОДНО красное `#F2382B` свечение-контровой свет справа сзади (как от невидимой красной лампы/неоновой вывески за кадром), туман над водой в фоне.

---

## 1. Общая механика (Home)

- Главная — одна sticky-сцена `.story` на ~9 экранов (как `scena-piekna`: `story__stage` + `story__panel`). Объект (кадры K1–K7) закреплён, текстовые панели проезжают слева.
- Прогресс главы 0..1 управляет кадром: кадр N-1 → N кроссфейдом через маску (круг/клин/«капля» — по главе), +частицы canvas (пыль в свете, мука, искры), +лёгкий scale/rotate.
- Фоны глав (§11): BG-A (река), BG-B (тёмный магазин-боке), BG-C (улица) сменяются **круглой волной из центра корзины**; Ken Burns 1.00→1.06 на главу; параллакс от мыши ±12px.
- Большое слово за объектом: Sora 300, `clamp(8rem, 22vw, 26rem)`, `--ivory` с opacity .06, частично перекрыто корзиной. Слова — польские (это и есть характер сайта), в PL-версии те же.
- Без стыков: общий фон `--ink`, у фото-слоёв градиенты ::before/::after в `--ink`.
- Счётчик слева снизу: `koszyk · 3 / 8` (строчные, Figtree 500 13px), точки-навигация справа.
- Lenis + доводка к ближайшему кадру.
- **Мобильная раскладка (все главы):** корзина сверху 45vh (sticky, кадр центрирован — `object-position: 64% 50%`), большое слово уходит за корзину по центру, текстовая панель снизу на `--ink-2` стекле, 1 абзац видно сразу + «lees meer» раскрывает остальные. Стеклянные плашки — в ряд по 2–3, горизонтальный скролл запрещён (wrap).

---

## 2. Главы Home (8 + финал)

### Глава 0 — HERO · «пełny koszyk» (0 → 0.10 скролла истории)
- **Кадр:** K6 — полная корзина, укрытая ivory-полотенцем, из-под него угадываются хлеб и банка; красный контровой свет по краю плетения. Фон BG-A (река Warta ночью, туман).
- **Превращение:** при загрузке: туман рассеивается, красный свет «загорается» (мерцание 2 вспышки), заголовок выезжает по словам. При скролле текст hero растворяется, камера влетает в корзину (scale 1→1.15) — переход в гл.1.
- **Слово за объектом:** `warta`.
- **Тексты:** чип `Poolse supermarkt · Waalwijk`; h1 строчными (тема: польский вкус рядом с домом, «om de hoek»), lead 1–2 предложения; кнопки: акцент `Bel 0416 203 437` (текст `--ink`), контурная `Route plannen`. Стеклянные плашки (только факты): `Stationsstraat 126` / `0416 203 437` / `NL · PL`. Стеклянная полоса вкладок внизу: `Brood · Voorraad · Vers · Contact` → якоря на главы (подписи вкладок = темы глав, не утверждения ассортимента).
- **Мобильно:** кадр сверху 50vh, h1 4 строки, плашки 3 в ряд мелко.

### Глава 1 — «пусто» · имя Warta (0.10 → 0.22)
- **Кадр:** K6 → K1. Полотенце приподнимается (кадр K2 мелькает на 30% прогресса), предметы растворяются вверх в тёплую пыль (canvas particles цвета ivory, 1–2 красные искры) → пустая корзина K1.
- **Маска:** вертикальная «шторка дыма» снизу вверх.
- **Фон:** BG-A (река), туман плывёт слева направо.
- **Слово:** `rzeka`.
- **Тексты (тема):** откуда имя — Warta, одна из больших рек Польши; магазин назван по ней → кусочек дома в Waalwijk. 3 абзаца: о названии; о том, что значит «свой» магазин для тех, кто живёт далеко от дома; о том, что голландцы тоже заходят за любопытными вкусами. Факт-плашка: `Warta — rivier in Polen`.
- **Мобильно:** стандарт.

### Глава 2 — «lniany ręcznik» · как дома (0.22 → 0.32)
- **Кадр:** K1 → K2: ivory льняное полотенце ложится в корзину (маска-«волна ткани» по диагонали слева-сверху).
- **Фон:** BG-A → BG-B (круглая волна из центра корзины).
- **Слово:** `dom`.
- **Тексты:** польская привычка ходить за продуктами с корзиной/сумкой, накрывать хлеб полотенцем; магазин как место, где говорят на твоём языке (NL + PL — сайт двуязычный; «spreekt men Pools» — НЕ писать как факт, только `[TE BEVESTIGEN]`). 2–3 абзаца.
- **Интерактив-тизер:** переключатель NL/PL прямо в панели — заголовок главы меняется на другой язык с анимацией по буквам.

### Глава 3 — «chleb» · хлеб (0.32 → 0.44)
- **Кадр:** K2 → K3: круглый тёмный ржаной каравай опускается сверху в корзину (translateY -40px → 0 + лёгкий отскок), из-под него поднимается облачко муки (canvas, ivory частицы).
- **Фон:** BG-B (тёмный магазин, боке тёплых ламп).
- **Слово:** `chleb`.
- **Тексты:** о роли хлеба в польском столе (ржаной, на закваске, завтрак/kolacja) — общее о культуре. Последний абзац: «Welk brood er bij Warta ligt? `[TE BEVESTIGEN]`». Подпись `Sfeerbeeld`.

### Глава 4 — «słoik» · запасы (0.44 → 0.56)
- **Кадр:** K3 → K4: стеклянная банка без этикетки (огурцы в рассоле, укроп) встаёт рядом с хлебом; блик пробегает по стеклу (CSS-shine по маске банки), красный свет преломляется в стекле.
- **Маска:** круглая «капля» из точки банки.
- **Фон:** BG-B.
- **Слово:** `słoik`.
- **Тексты:** культура заготовок — ogórki kiszone, варенья, «бабушкина кладовка»; почему вкус из банки = вкус детства. Подпись `Sfeerbeeld`, без утверждений о наличии.

### Глава 5 — «na stół» · к столу (0.56 → 0.68)
- **Кадр:** K4 → K5: кольцо копчёной колбасы и стеклянная бутылка молока появляются в корзине (клин справа налево, как разрез).
- **Фон:** BG-B, лёгкий пар/дымка над корзиной (canvas).
- **Слово:** `stół`.
- **Тексты:** польский стол как повод собраться: завтрак, обед в воскресенье, праздники (Wigilia, Wielkanoc — как культура, без обещаний сезонных товаров). Мясное/молочное — только как общее, `[TE BEVESTIGEN]` для групп. Подпись `Sfeerbeeld`.

### Глава 6 — «pełny» · всё в одной корзине → Assortiment (0.68 → 0.80)
- **Кадр:** K5 → K6: полотенце сворачивается поверх (маска-диагональ, обратная гл.2). Красное свечение достигает максимума.
- **Фон:** BG-B → тёмный (`--ink`) с красным ореолом за корзиной.
- **Слово:** `koszyk`.
- **Тексты + приём:** вместо карточек — **«список покупок»**: рукописно-тонкий (Sora 300) список групп товаров, строки которого «прокрашиваются» ivory по скроллу: `brood & gebak · zuivel · vleeswaren · voorraadkast · snoep · dranken` — **каждая с меткой `[TE BEVESTIGEN]`** (группы — заглушки до подтверждения клиентом). Кнопка `Bekijk assortiment` (контурная).

### Глава 7 — «za rogiem» · om de hoek (0.80 → 0.92)
- **Кадр:** K6 → K7: камера отъезжает, корзина оказывается на каменном пороге у приоткрытой двери на мокрой ночной улице; красный отсвет из окна на брусчатке. Переход — zoom-out + круглая волна BG-C.
- **Фон:** BG-C (голландская кирпичная улица ночью, без узнаваемых фасадов/вывесок).
- **Слово:** `waalwijk`.
- **Тексты:** Stationsstraat 126, 5141 GH Waalwijk; как дойти (общее: «in het centrum van Waalwijk» — НЕ писать расстояния/парковку без проверки); часы `[OPENINGSTIJDEN TE BEVESTIGEN]`; Facebook. 2 абзаца + стеклянные плашки: адрес / телефон / часы-заглушка.
- Кнопки: `Route plannen` (Google Maps по адресу) + `Bel`.

### Финал — «do zobaczenia» (0.92 → 1.0, затем отдельная секция `.finale`)
- **Кадр:** K7 уходит в затемнение, остаётся только красное свечение → проявляется финальный фон (K7 крупнее, Ken Burns) с искрами/светлячками (canvas `sparks`, ivory + 1 из 10 красная).
- **Тексты:** короткий h2 (тема: «zie je om de hoek» / «do zobaczenia»), 1 строка, кнопки `Bel 0416 203 437` + `Route`. Футер: адрес, телефон, Facebook, плашка `Ontwerpvoorstel door ITty Company. Afbeeldingen zijn sfeerbeelden.`

Объём текста Home ≥ 900 слов (каждая глава: h2 + 2–4 абзаца). Copywriter пишет NL + PL.

---

## 3. Внутренние страницы

### Assortiment (`assortiment.html`)
- **Hero:** F11 (вид сверху на разложенное содержимое корзины на полотенце, 3:4 справа) поверх BG-B; h1 о «полке из дома»; чип `Productgroepen — te bevestigen`.
- **Приём 1 — горизонтальная закреплённая лента групп** (не карточки): на ней большие польские слова `chleb · nabiał · wędliny · spiżarnia · słodycze · napoje`, при наведении/скролле слово «подсвечивается» красным glow, справа ivory-перевод NL и 2–3 предложения общего текста о категории + `[TE BEVESTIGEN]`. Фото для групп — НЕТ, вместо них фрагменты F11 (кроп через `object-position`) с подписью `Sfeerbeeld`.
- **Приём 2 — интерактив «Mijn boodschappenlijst / Moja lista»:** см. §5.
- Блок-заглушка: «Hier komen foto's van de echte schappen van Warta» (рамка-пунктир ivory .2, по §7).
- Финал общий.

### Over ons (`over-ons.html`)
- **Hero:** BG-A (река Warta ночью, один красный огонёк отражается в воде).
- **Секция «naam»:** текст, который прокрашивается при скролле: «Warta» → река → магазин в Waalwijk. Фото F12 (крупно плетение ручки корзины в тумане, 3:4).
- **Секция «waarom»:** ценности без выдумки (рядом, двуязычно, «как дома») — формулировать как намерение, не как историю. Никаких лет/владельцев/персонала.
- **Линия-процесс, рисуется при скролле:** река → дорога → дверь магазина (SVG-путь, красная точка едет по линии).
- Финал общий.

### Contact (`contact.html`)
- **Hero:** K7 (корзина на пороге, ночная улица).
- **Стеклянная сетка:** Adres (Stationsstraat 126, 5141 GH Waalwijk) · Telefoon 0416 203 437 · Openingstijden `[TE BEVESTIGEN]` · Facebook. Email/Instagram НЕ ставить.
- **Карта:** статичная тёмная SVG-карта-схема (кодом, без тайлов) с красной точкой и кнопкой «Open in Google Maps».
- Финал общий.

---

## 4. Переход между страницами
- Шторка в 2 слоя: `--ink-2` снизу вверх, за ней `--ink`; по центру тонкий силуэт корзины (SVG-линия ivory 1px), над ней красная точка-«лампа», которая вспыхивает; название страницы Sora 300 строчными (`assortiment.` / `over ons.` / `contact.`), в PL — по-польски.
- Направление: вперёд по меню — шторка снизу вверх, назад — сверху вниз; контент уходит с `rotateX(6deg) translateZ(-80px)`.
- На телефоне — та же шторка без 3D-наклона.

## 5. Интерактивы по нише (2–3)
1. **«Moja lista / Mijn boodschappenlijst»** (Assortiment): тапаешь группы — их иконки «падают» в SVG-корзину (физика-лайт), список можно скопировать/распечатать или открыть звонок `tel:`. Группы — заглушки `[TE BEVESTIGEN]`. Без цен, без корзины-заказа (онлайн-заказа нет).
2. **«Słowo/woord»** (Home гл.2 и Assortiment): тап по польскому слову на большом фоне (chleb, słoik, twaróg…) переворачивает его в NL с произношением-подсказкой; для голландских посетителей — мостик к польской кухне. Чисто культурный контент, не утверждение ассортимента.
3. **NL/PL переключатель с анимацией** — весь сайт; запоминается в localStorage (try/catch).

## 6. Кадры кампании с людьми
Не генерировать (предпочтение «без людей»; персонал/клиенты неизвестны). Если позже понадобятся — максимум 2, с подписью `Voorbeeldbeeld`.

---

## 7. ПРОМПТЫ — Higgsfield `gpt_image_2_6` (12 кадров, всего)

### Общий якорь (вставлять в КАЖДЫЙ промпт кадров K1–K7, F11, F12 — дословно)
```
ANCHOR: Cinematic premium advertising photograph. Camera: three-quarter front view, 25 degrees above the counter, 50mm lens, shallow depth of field. A round hand-woven natural willow wicker basket with a single arched handle stands on a dark weathered oak counter. Basket placed in the right half of the frame (its center at about 64% from the left, 55% from the top), basket height about 45% of the frame. The left 40% of the frame is empty, very dark negative space. Background: deep ink navy #0A1626 night atmosphere with soft drifting mist. Lighting: soft warm ivory #F7F0DF key light from upper left; ONE single red #F2382B rim glow from behind on the right, as if from an unseen red lamp, catching the edges of the wicker and the oak grain. Only one red accent in the whole image. Fine film grain, rich shadows, moody, quiet luxury. No text, no logos, no labels, no brands, no people, no hands.
```

| # | ID / файл | Где | Формат | Ссылается на | Промпт (после ANCHOR, если указано) |
|---|---|---|---|---|---|
| 1 | **K1** `k1-empty.webp` | Home гл.1 | 16:9 | — (это мастер-кадр, генерировать ПЕРВЫМ) | `ANCHOR` + `The basket is completely empty; we see the woven interior bottom. Nothing else on the counter.` |
| 2 | **K2** `k2-cloth.webp` | Home гл.2 | 16:9 | **K1** (image reference, keep camera, basket, counter, light identical) | `ANCHOR` + `Same scene and basket as the reference image. Now a folded natural ivory linen tea towel with a thin woven border lies inside the basket, one corner draping softly over the rim towards the camera.` |
| 3 | **K3** `k3-bread.webp` | Home гл.3 | 16:9 | **K2** | `ANCHOR` + `Same scene as the reference image. A round dark rustic rye sourdough loaf with a floured, cracked crust now rests on the linen inside the basket. A faint dusting of flour in the air, catching the ivory light.` |
| 4 | **K4** `k4-jar.webp` | Home гл.4 | 16:9 | **K3** | `ANCHOR` + `Same scene as the reference image. Next to the loaf, a plain glass preserving jar with a metal clip lid stands in the basket, filled with pickled cucumbers, dill and garlic in clear brine, no label. The red rim light refracts through the glass and brine.` |
| 5 | **K5** `k5-table.webp` | Home гл.5 | 16:9 | **K4** | `ANCHOR` + `Same scene as the reference image. Added to the basket: a ring of dark smoked sausage tied with natural string draped over the loaf, and a small unlabeled glass bottle of milk. A thin wisp of warm haze above the basket.` |
| 6 | **K6** `k6-full.webp` (= HERO) | Home hero + гл.6 | 16:9 | **K5** | `ANCHOR` + `Same scene as the reference image. The ivory linen towel is now folded back over the full basket, partly covering it; the top of the loaf, the jar lid and the bottle neck peek out. The red rim glow is slightly stronger, a glowing red edge along the handle. Hero composition: generous empty dark space on the left for a headline.` |
| 7 | **K7** `k7-doorstep.webp` | Home гл.7, финал, Contact hero | 16:9 | **K6** (same basket and contents, new place) | `Cinematic premium advertising photograph, same wicker basket with ivory linen towel and contents as the reference image, now standing on a worn stone doorstep of a half-open dark wooden shop door on a quiet Dutch brick street at night after rain. Wet cobblestones reflect a single red #F2382B glow coming from inside the doorway; soft warm ivory #F7F0DF streetlight from the upper left; deep ink navy #0A1626 night sky and mist. Camera three-quarter front, 50mm, slightly lower than before. Basket in the right half of the frame, left 40% empty dark street. No readable signs, no text, no logos, no house numbers, no people. Fine film grain, moody, quiet luxury.` |
| 8 | **BG-A** `bg-river.webp` | Home hero/гл.1–2 фон, Over ons hero | 16:9 | — (стиль сверять с K1: тот же navy, туман, грейн) | `Cinematic night landscape photograph of a wide calm Polish river with low mist drifting over black water, a line of dark willow trees on the far bank, deep ink navy #0A1626 sky, faint warm ivory #F7F0DF moonlight on the water surface, and one single small red #F2382B light far away on the right bank reflected as a long red streak in the water. Center and left of the frame calm and empty for overlays. No people, no boats, no text, no buildings. Fine film grain, quiet, premium.` |
| 9 | **BG-B** `bg-shop.webp` | Home гл.2–6 фон, Assortiment hero фон | 16:9 | **K1** (тот же свет и тон) | `Cinematic, heavily out-of-focus interior of a small dark grocery shop at night after closing: blurred rows of shelves with indistinct jars, bottles and bread shapes, warm ivory #F7F0DF bokeh from a few hanging lamps, deep ink navy #0A1626 shadows, and one single red #F2382B glow on the right like a lamp reflected on glass. The center of the frame is dark and empty for an object overlay. Nothing in focus, no readable labels, no brands, no text, no people. Fine film grain, moody, premium.` |
| 10 | **BG-C** `bg-street.webp` | Home гл.7 фон | 16:9 | **K7** (та же улица, но БЕЗ корзины, шире) | `Same Dutch brick street at night after rain as the reference image, wider view, without the basket: wet cobblestones, low brick facades, warm ivory #F7F0DF streetlights, deep ink navy #0A1626 sky with mist, one single red #F2382B glow spilling from a shop doorway on the right. Center of the frame empty and dark. No readable signs, no text, no logos, no people, no cars. Fine film grain, cinematic.` |
| 11 | **F11** `f11-flatlay.webp` | Assortiment hero + кропы групп | 3:4 | **K6** (те же предметы и полотенце) | `Top-down cinematic still life on the same dark weathered oak counter: the ivory linen towel from the reference image laid flat, and on it, neatly arranged with generous spacing, the same items: the round rye sourdough loaf, the unlabeled jar of pickled cucumbers, the ring of smoked sausage with string, the small milk bottle, plus a few loose dill sprigs. The empty wicker basket at the top edge, partly cropped. Deep ink navy #0A1626 surroundings, soft warm ivory #F7F0DF light from the upper left, one single red #F2382B glow grazing from the right edge. No text, no labels, no brands, no people, no hands. Fine film grain, premium.` |
| 12 | **F12** `f12-handle.webp` | Over ons («naam») | 3:4 | **K1** (та же корзина) + **BG-A** (туман/река) | `Cinematic close-up of the arched handle and woven rim of the same willow wicker basket as the reference image, standing on a wooden jetty edge at night by a misty river; behind it out of focus, black water with drifting mist and one red #F2382B light reflected as a long streak. Deep ink navy #0A1626 atmosphere, warm ivory #F7F0DF light on the wicker from the upper left. Upper part of the frame dark and calm for a title. No text, no logos, no people. Fine film grain, quiet luxury.` |

**Порядок генерации (цепочка непрерывности):** K1 → K2 → K3 → K4 → K5 → K6 → K7 → BG-C; параллельно независимые BG-A, BG-B (ref K1); затем F11 (ref K6), F12 (ref K1 + BG-A).
**Проверка после генерации:** у K1–K6 корзина в одной точке кадра (допуск ±3% по X/Y) — иначе выровнять кропом/сдвигом перед кроссфейдом; нет текста/этикеток (если модель нарисовала этикетку на банке — перегенерировать); один красный источник; экспорт webp 1920×1080 (16:9) и 1200×1600 (3:4).
**Вырезка:** K1–K6 дополнительно вырезать по контуру корзины в прозрачный webp (OpenCV/rembg) для слоя объекта поверх сменяющихся фонов BG-A/BG-B; полный кадр — фолбэк без WebGL.

---

## 8. Что нужно от клиента (влияет на историю)
Группы товаров (заменят заглушки гл.6 и Assortiment), часы работы (гл.7, Contact), реальные фото витрины/фасада (заменят F11 и K7 как «Sfeerbeeld»), говорят ли в магазине по-польски/по-голландски.
