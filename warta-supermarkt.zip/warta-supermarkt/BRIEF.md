# BRIEF — Warta Supermarkt (Waalwijk)

slug: `warta-supermarkt` · ниша: польский продуктовый супермаркет (Supermarkt) · язык сайта: Nederlands + Polski (переключатель), см. «Язык клиентов»
Дата сбора: 17.11.2026

## Подтверждённые факты (с источниками)
| Факт | Значение | Источник |
|---|---|---|
| Название | Warta Supermarkt Topolanka BV | https://lokaalnieuwswaalwijk.nl/warta-supermarkt-topolanka-bv/ |
| Категория | «Supermarkt»; «een supermarkt gevestigd in Waalwijk» | там же |
| Адрес | Stationsstraat 126, 5141 GH Waalwijk | там же (улица/номер); индекс 5141 GH — из данных лида (leads.csv) |
| Телефон | 0416 203 437 (= +31 416 203 437) | там же |
| Facebook | https://www.facebook.com/Wartasupermarktwaalwijk/ | существует (из лида); содержимое не читается (robots_disallowed) |
| Свой сайт | нет — на lokaalnieuwswaalwijk.nl сайт не указан, единственная внешняя ссылка — Google Maps | https://lokaalnieuwswaalwijk.nl/warta-supermarkt-topolanka-bv/ |
| Польский профиль | «Polish supermarket» — из данных лида/выбора клиента; название «Warta» = польская река | данные лида (внешним источником текстом не подтверждено) |

## НЕ подтверждено / НЕИЗВЕСТНО (не писать на сайте как факт)
- **Часы работы** — нигде не найдены (lokaalnieuws: «Not listed»; Facebook не читается). На сайте ставить `[OPENINGSTIJDEN TE BEVESTIGEN]`.
- **Ассортимент** — неизвестен. Нет подтверждения про пекарню, мясной/колбасный прилавок, конкретные бренды, алкоголь, свежий хлеб, доставку. Допустимо только общее «Poolse supermarkt / Poolse producten» с пометкой `[TE BEVESTIGEN]`; конкретные группы товаров — заглушки.
- **Рейтинг Google / число отзывов** — не найден ни в одном доступном источнике. Звёзды не писать.
- **Email** — нигде публично не найден. Оставить пустым, только телефон + Facebook.
- **Instagram** — не найден. Не ставить иконку.
- **KvK-номер Warta / Topolanka BV (Waalwijk)** — не найден. Внимание, не путать:
  - `Topolanka Rotterdam (BV)`, KvK 77045726, Wolphaertsbocht 11 Rotterdam, «retail sale of foreign food products» — https://www.liza.nl/en/77045726/topolanka-rotterdam — связь с Waalwijk/Warta **не подтверждена**, Waalwijk-филиал там не указан.
  - `Polski Supermarket Waalwijk (BV)`, KvK 93068921, De Kroonweg 2, с 23-02-2024 — https://www.liza.nl/en/93068921/polski-supermarket-waalwijk — Warta/Topolanka **не упоминаются**, вероятно другой магазин (возможный конкурент). На сайте не использовать.
- Год открытия, история, владельцы, персонал, фото магазина — неизвестно, не упоминать.
- Язык клиентов фактически не подтверждён (нет отзывов/постов). Украинская аудитория — **не подтверждена**, не писать «ми говоримо українською».

## Язык клиентов (оценка, не факт)
Польский магазин в Waalwijk → основная аудитория вероятно польскоязычная (трудовые мигранты региона), плюс голландцы. Рекомендация: NL основной + PL версия. UK/EN — только если клиент подтвердит.

## Что слабо в онлайн-присутствии сейчас
1. Своего сайта нет — только Facebook и запись в справочнике lokaalnieuwswaalwijk.nl.
2. Facebook закрыт для поисковиков → часы, ассортимент и акции не видны в Google.
3. В справочнике нет часов, email, описания ассортимента — только «een supermarkt in Waalwijk».
4. По запросам «Warta supermarkt Waalwijk», «Poolse supermarkt Waalwijk» поиск выдаёт новости и другие магазины, но не Warta (наши 3 запроса — ни одного результата про магазин). При этом в Waalwijk есть как минимум ещё одна зарегистрированная BV «Polski Supermarket Waalwijk» — конкуренция за тот же запрос.

## Что сказать клиенту (RU)
«Сейчас Warta в Google почти не находится: нет сайта, нет часов работы, Facebook поисковик не видит, а по запросу „Poolse supermarkt Waalwijk“ люди находят других. Мы сделали вам простой сайт на голландском и польском — адрес, часы, что у вас есть, телефон и кнопка маршрута.»

## Перед показом клиенту — уточнить вручную
Часы работы, группы товаров (хлеб/выпечка? мясо/колбасы? молочка? сладости? алкоголь?), фото витрины/фасада, email, Instagram, KvK-номер, рейтинг в Google Maps (открыть карточку вручную).

## Источники
- https://lokaalnieuwswaalwijk.nl/warta-supermarkt-topolanka-bv/
- https://www.facebook.com/Wartasupermarktwaalwijk/ (не читается, robots)
- https://www.liza.nl/en/77045726/topolanka-rotterdam (для разграничения)
- https://www.liza.nl/en/93068921/polski-supermarket-waalwijk (для разграничения)
