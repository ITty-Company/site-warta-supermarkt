# COPY — Warta Supermarkt (Waalwijk)

Rol: copywriter · input: BRIEF.md, STORY.md, PALETTE.md, TYPE.md, DESIGN_STANDARD (★ GLAVNY STIJL + §7 + §10)
Datum: 17.11.2026 · Taal: **Nederlands (hoofdtaal)** met Poolse woorden als accent. Onderaan: **PL-kernteksten** voor de NL/PL-schakelaar (STORY §5.3).

## Regels voor de builder (niet op de site zetten)
- Koppen: **kleine letters, kort, eindigen met een punt.** Boven elke kop een chip (Figtree 500, kleine letters).
- Poolse woorden staan cursief-vrij in hetzelfde lettertype (Sora/Figtree), met correcte diakritiek: ą ę ł ń ó ś ź ż.
- Alleen deze feiten zijn hard: **Warta Supermarkt**, **Stationsstraat 126, 5141 GH Waalwijk**, **0416 203 437** (`tel:+31416203437`), **Facebook** `https://www.facebook.com/Wartasupermarktwaalwijk/`, «Poolse supermarkt», «Warta = rivier in Polen».
- Alles over assortiment = algemeen over de Poolse keuken + label `[TE BEVESTIGEN]`. Openingstijden = `[OPENINGSTIJDEN TE BEVESTIGEN]`. Geen e-mail, geen Instagram, geen prijzen, merken, sterren, reviews, jaartallen, personeel, bezorging, parkeren of afstanden.
- Placeholders in de HTML zichtbaar laten als klein label (Figtree 500 12px, `--kielbasa-glow`, stippelrand) zodat de klant ze herkent.
- Onder elk beeld met producten de bijschrift-regel (zie §Bijschriften).
- Route-link: `https://www.google.com/maps/dir/?api=1&destination=Stationsstraat+126,+5141+GH+Waalwijk`
- Kaart-link: `https://www.google.com/maps/search/?api=1&query=Stationsstraat+126,+5141+GH+Waalwijk`

---

## Globaal

### Banner (vast, bovenaan of onderaan, klein)
**Ontwerpvoorstel — ITty Company**
Subregel (optioneel, bij hover/tap): `Dit is een voorbeeldontwerp. Afbeeldingen zijn sfeerbeelden.`

### Navigatie
- Logo: `warta.` (Sora 300) + klein `supermarkt · waalwijk`
- Menu: `Home` · `Assortiment` · `Over ons` · `Contact`
- Pil-knop rechts (ivory): `Bel 0416 203 437`
- Taalschakelaar: `NL` / `PL`
- Mobiel menu: knop `menu` / `sluiten`; onderaan in het menu: `Stationsstraat 126, Waalwijk` + `Bel 0416 203 437`

### Knoppen (vaste teksten)
| Doel | NL | PL |
|---|---|---|
| Bellen (accent) | `Bel 0416 203 437` | `Zadzwoń: 0416 203 437` |
| Bellen kort | `Bel` | `Zadzwoń` |
| Route (contour) | `Route plannen` | `Wyznacz trasę` |
| Kaart | `Open in Google Maps` | `Otwórz w Google Maps` |
| Facebook | `Volg ons op Facebook` | `Obserwuj nas na Facebooku` |
| Naar assortiment | `Bekijk assortiment` | `Zobacz asortyment` |
| Meer tekst (mobiel) | `lees meer` / `minder` | `czytaj dalej` / `mniej` |
| Lijst kopiëren | `Kopieer lijst` | `Kopiuj listę` |
| Lijst printen | `Print lijst` | `Drukuj listę` |
| Lijst leegmaken | `Begin opnieuw` | `Zacznij od nowa` |

### Paginaovergang (gordijn-titels)
NL: `home.` · `assortiment.` · `over ons.` · `contact.`
PL: `start.` · `asortyment.` · `o nas.` · `kontakt.`

### Bijschriften
- Kort (op beeld): **Sfeerbeeld**
- Volledig (onder elk productbeeld, 12–13px `--mist`): `Sfeerbeeld — geen weergave van het actuele assortiment.`
- PL: `Zdjęcie poglądowe — nie przedstawia aktualnego asortymentu.`
- Straat-/rivierbeelden: `Sfeerbeeld` (zonder assortimentszin).

### Footer
- Kolom 1: `warta.` — `Poolse supermarkt in Waalwijk.`
- Kolom 2 — **Adres**: `Stationsstraat 126` / `5141 GH Waalwijk`
- Kolom 3 — **Telefoon**: `0416 203 437`
- Kolom 4 — **Openingstijden**: `[OPENINGSTIJDEN TE BEVESTIGEN]`
- Kolom 5 — **Volg ons**: `Facebook`
- Menu herhaald: `Home · Assortiment · Over ons · Contact`
- Onderregel: `Ontwerpvoorstel door ITty Company. Afbeeldingen zijn sfeerbeelden.`
- Kleine slotregel: `do zobaczenia — tot ziens.`

### Meta
| Pagina | `<title>` | `meta description` |
|---|---|---|
| Home | `Warta Supermarkt — Poolse supermarkt in Waalwijk` | `Warta Supermarkt is een Poolse supermarkt aan de Stationsstraat 126 in Waalwijk. Bel 0416 203 437 of plan je route.` |
| Assortiment | `Assortiment — Warta Supermarkt Waalwijk` | `Poolse productgroepen bij Warta Supermarkt in Waalwijk: van chleb tot spiżarnia. Assortiment wordt nog bevestigd — bel 0416 203 437.` |
| Over ons | `Over ons — Warta Supermarkt Waalwijk` | `Warta is een rivier in Polen en een Poolse supermarkt in Waalwijk. Lees waar de naam vandaan komt en waar we voor staan.` |
| Contact | `Contact — Warta Supermarkt, Stationsstraat 126 Waalwijk` | `Warta Supermarkt, Stationsstraat 126, 5141 GH Waalwijk. Telefoon 0416 203 437. Route, Facebook en openingstijden.` |

PL-meta:
| Strona | `<title>` | `meta description` |
|---|---|---|
| Start | `Warta Supermarkt — polski sklep w Waalwijk` | `Warta Supermarkt to polski supermarket przy Stationsstraat 126 w Waalwijk. Zadzwoń: 0416 203 437 lub wyznacz trasę.` |
| Asortyment | `Asortyment — Warta Supermarkt Waalwijk` | `Polskie grupy produktów w Warta Supermarkt w Waalwijk. Asortyment do potwierdzenia — zadzwoń: 0416 203 437.` |
| O nas | `O nas — Warta Supermarkt Waalwijk` | `Warta to polska rzeka i polski supermarket w Waalwijk. Skąd nazwa i co jest dla nas ważne.` |
| Kontakt | `Kontakt — Warta Supermarkt, Stationsstraat 126 Waalwijk` | `Warta Supermarkt, Stationsstraat 126, 5141 GH Waalwijk. Tel. 0416 203 437. Trasa, Facebook i godziny otwarcia.` |

---

# HOME (`index.html`)

Teller linksonder: `koszyk · 1 / 8` … `koszyk · 8 / 8` (Hero = 1, gl.1 = 2 … gl.7 = 8; finale zonder teller).

## Hoofdstuk 0 — HERO · pełny koszyk
- Groot woord achter object: `warta`
- Chip: `Poolse supermarkt · Waalwijk`
- **H1:** `poolse smaken, om de hoek.`
- Lead: `Warta Supermarkt aan de Stationsstraat in Waalwijk. Een stukje Polen voor wie het mist — en een ontdekking voor wie nieuwsgierig is naar de Poolse keuken.`
- Knoppen: `Bel 0416 203 437` (accent) · `Route plannen` (contour)
- Glazen plaatjes (alleen feiten):
  - `Stationsstraat 126` — `5141 GH Waalwijk`
  - `0416 203 437` — `bel ons`
  - `NL · PL` — `website in twee talen`
- Glazen tabbalk onderaan: `Brood` → #chleb · `Voorraad` → #sloik · `Vers` → #stol · `Contact` → #za-rogiem
- Scroll-hint: `scroll — de mand vult zich`
- Bijschrift: `Sfeerbeeld`

## Hoofdstuk 1 — rzeka · de naam (id `rzeka`)
- Groot woord: `rzeka`
- Chip: `rzeka · rivier`
- **H2:** `vernoemd naar een rivier.`

De Warta is een van de grote rivieren van Polen. Ze stroomt door het westen van het land, langs velden, wilgen en oude stadjes, en ze is voor veel Polen gewoon een stukje van thuis. Een supermarkt die die naam draagt, belooft geen grootse dingen. Hij belooft iets kleiners en mooiers: een vertrouwd gevoel, hier in Waalwijk.

Wie ver van huis woont en werkt, weet hoe dat voelt. Je went aan een nieuwe stad, nieuwe straten en een nieuwe taal, maar sommige dingen wil je gewoon blijven kennen. De smaak van je ontbijt. De pot op de plank. Een winkel waar je niet hoeft na te denken, omdat je vanzelf de weg weet. Daar is een eigen winkel om de hoek voor.

En voor Nederlanders? Ook voor jou staat de deur open. De Poolse keuken is stevig, eerlijk en verrassend veelzijdig. Zuur en zout, rokerig en zoet, eenvoudig en feestelijk. Wie eenmaal nieuwsgierig binnenloopt, ontdekt een hele keuken die ver weg begint en hier, in de Stationsstraat, gewoon om de hoek ligt.

- Glazen plaatje: `Warta` — `rivier in Polen`
- Bijschrift achtergrond: `Sfeerbeeld`

## Hoofdstuk 2 — dom · zoals thuis (id `dom`)
- Groot woord: `dom`
- Chip: `lniany ręcznik · linnen doek`
- **H2:** `zoals thuis, maar dan hier.`
- Interactieve teaser (schakelaar in paneel): kop wisselt naar PL → `jak w domu, tylko tutaj.`

In veel Poolse huizen gaat het boodschappen doen nog een beetje ouderwets. Een mand of een stevige tas aan de arm, een linnen doek erover zodat het brood warm blijft en niets uit de mand valt. Het is geen nostalgie, het is gewoon hoe het altijd ging: met aandacht kiezen, en thuis alles netjes op tafel zetten.

Een eigen winkel is meer dan schappen en een kassa. Het is een plek waar de namen op de verpakkingen klinken zoals je ze kent, waar je zonder vertalen ziet wat je zoekt, en waar het voelt alsof je even niet in het buitenland bent. Of je bij Warta in het Pools geholpen wordt? `[TE BEVESTIGEN]`

Deze website spreekt in elk geval beide talen. Tik rechtsboven op `NL` of `PL` en lees alles in de taal die het beste voelt. Dzień dobry, goedendag — het komt op hetzelfde neer: welkom binnen.

- Tik-hint: `tik op het woord — słowo/woord`
- Bijschrift: `Sfeerbeeld — geen weergave van het actuele assortiment.`

## Hoofdstuk 3 — chleb · brood (id `chleb`)
- Groot woord: `chleb`
- Chip: `chleb · brood`
- **H2:** `alles begint bij brood.`

Op een Poolse tafel is brood geen bijzaak. Het staat er bij het ontbijt, bij de kolacja in de avond en bij bijna alles daartussen. Vaak is het donker en stevig: roggebrood, met een dikke korst en een zachte, licht zure kruim. Brood dat je niet zomaar weg eet, maar dat de hele dag meegaat.

Het geheim zit vaak in de zakwas, het zuurdesem dat langzaam zijn werk doet. Dat geeft het brood zijn karakter en zijn geur. Een snee met boter, een plak ham of een schep twaróg, een paar plakjes komkommer erop — meer is het niet, en meer hoeft het ook niet te zijn. Śniadanie in zijn eenvoudigste en eerlijkste vorm.

Brood wordt in Polen met respect behandeld. Je gooit het niet weg, je zet het netjes op tafel, en bij feestdagen krijgt het een hoofdrol. Welk brood er bij Warta in het schap ligt, en op welke dagen? `[TE BEVESTIGEN]`

- Bijschrift: `Sfeerbeeld — geen weergave van het actuele assortiment.`

## Hoofdstuk 4 — słoik · de voorraadkast (id `sloik`)
- Groot woord: `słoik`
- Chip: `słoik · pot`
- **H2:** `de smaak van een volle kast.`

Ogórki kiszone: komkommers in pekel met dille en knoflook, die een paar weken rustig mogen gisten tot ze die typische zure frisheid krijgen. Voor veel Polen is dat de smaak van thuis. Geen azijn, maar zout, water en tijd. Het resultaat staat in glazen potten op de plank en verdwijnt sneller dan je denkt.

Inmaken is in Polen een gewoonte die van generatie op generatie gaat. In de zomer en de herfst worden groente, fruit en paddenstoelen ingelegd, gekookt en in potten gezet. Jam, compote, zuurkool, rode biet. De spiżarnia, de voorraadkast van oma, is een begrip: een plek vol kleuren en herinneringen, klaar voor de lange winter.

Daarom is een pot soms meer dan een product. Eén hap, en je zit weer aan de keukentafel van vroeger. Welke potten en conserven Warta voert? `[TE BEVESTIGEN]`

- Bijschrift: `Sfeerbeeld — geen weergave van het actuele assortiment.`

## Hoofdstuk 5 — stół · aan tafel (id `stol`)
- Groot woord: `stół`
- Chip: `na stół · op tafel`
- **H2:** `samen aan één tafel.`

In de Poolse keuken draait veel om de tafel zelf. Een uitgebreid ontbijt in het weekend, de zondagse lunch met soep vooraf, familie die blijft hangen tot het donker wordt. Er wordt gegeten, gepraat en nog eens opgeschept. Smacznego! zeg je voor het eten — eet smakelijk — en dat meen je.

Gerookte worst, ham, verse kaas en zuivel horen in veel Poolse keukens bij het dagelijks leven, op brood of in een warme maaltijd. Welke vleeswaren en zuivel er bij Warta te vinden zijn, bevestigen we nog met de winkel. `[TE BEVESTIGEN]`

En dan zijn er de feestdagen. Wigilia, het kerstavondmaal, waarop traditioneel geen vlees op tafel komt en er een leeg bord klaarstaat voor een onverwachte gast. Wielkanoc, Pasen, met de święconka: een mandje met brood, eieren, zout en worst dat in de kerk wordt gezegend. Dezelfde mand als in dit verhaal — zo ver komt een kleine traditie.

- Bijschrift: `Sfeerbeeld — geen weergave van het actuele assortiment.`

## Hoofdstuk 6 — koszyk · de volle mand (id `koszyk`)
- Groot woord: `koszyk`
- Chip: `pełny koszyk · volle mand`
- **H2:** `één mand, heel veel thuis.`

Brood, een pot uit de voorraadkast, iets voor op tafel. Zo vult een Poolse boodschappenmand zich vanzelf. Hieronder staat het boodschappenlijstje van een gemiddelde Poolse keuken. Welke groepen Warta precies in de schappen heeft, horen we binnenkort van de winkel zelf — tot die tijd staat er bij elke regel een label.

**Boodschappenlijst** (Sora 300, regels kleuren ivory bij scrollen):
- `brood & gebak` — chleb i wypieki `[TE BEVESTIGEN]`
- `zuivel` — nabiał `[TE BEVESTIGEN]`
- `vleeswaren` — wędliny `[TE BEVESTIGEN]`
- `voorraadkast` — spiżarnia `[TE BEVESTIGEN]`
- `snoep` — słodycze `[TE BEVESTIGEN]`
- `dranken` — napoje `[TE BEVESTIGEN]`

Twijfel je of iets er is? Bellen is altijd het snelst: `0416 203 437`.

- Knop: `Bekijk assortiment` (contour)
- Bijschrift: `Sfeerbeeld — geen weergave van het actuele assortiment.`

## Hoofdstuk 7 — za rogiem · om de hoek (id `za-rogiem`)
- Groot woord: `waalwijk`
- Chip: `za rogiem · om de hoek`
- **H2:** `gewoon om de hoek.`

Warta Supermarkt vind je aan de Stationsstraat 126 in Waalwijk. Geen grote hal aan de rand van de stad, maar een winkel in een gewone straat, waar je even binnenloopt op weg naar huis. Voor een brood, voor iets dat je mist, of gewoon om te kijken wat er op de planken staat.

Plan je route met één tik, of bel even vooraf als je wilt weten of iets er is. Warta is ook te vinden op Facebook. De openingstijden zetten we hier zodra ze bevestigd zijn: `[OPENINGSTIJDEN TE BEVESTIGEN]`

- Glazen plaatjes:
  - `Stationsstraat 126` — `5141 GH Waalwijk`
  - `0416 203 437` — `bel vooraf`
  - `[OPENINGSTIJDEN TE BEVESTIGEN]` — `openingstijden`
- Knoppen: `Route plannen` (accent) · `Bel` (contour)
- Tekstlink: `Volg ons op Facebook`
- Bijschrift: `Sfeerbeeld`

## Finale — do zobaczenia
- Chip: `do zobaczenia · tot ziens`
- **H2:** `tot zo, om de hoek.`
- Regel: `Stationsstraat 126, Waalwijk — bel 0416 203 437 of loop gewoon even binnen.`
- Knoppen: `Bel 0416 203 437` (accent) · `Route plannen` (contour)

*(Woordtelling Home NL, lopende tekst + koppen + plaatjes: ca. 1.150 woorden.)*

---

# ASSORTIMENT (`assortiment.html`)

## Hero
- Chip: `Productgroepen — te bevestigen`
- **H1:** `een schap vol thuis.`
- Lead: `Van chleb tot spiżarnia: dit zijn de productgroepen die in een Poolse keuken niet mogen ontbreken. Wat Warta precies verkoopt, bevestigen we nog met de winkel — bel gerust om het te vragen.`
- Knoppen: `Bel 0416 203 437` (accent) · `Route plannen` (contour)
- Glazen plaatje: `[TE BEVESTIGEN]` — `assortiment wordt aangevuld`
- Bijschrift: `Sfeerbeeld — geen weergave van het actuele assortiment.`

## Lint met groepen (horizontaal, sticky)
Intro boven het lint — chip `sześć słów · zes woorden` · **H2:** `zes woorden poolse keuken.`
`Schuif door het lint. Elk Pools woord staat voor een groep producten die in veel Poolse huishoudens dagelijks op tafel komt.`

1. **chleb** — *brood & gebak*
   `Donker roggebrood op zuurdesem, lichte bolletjes voor het ontbijt, en bij feestdagen zoet gebak met maanzaad of kwark. Brood is de basis van bijna elke Poolse maaltijd, van śniadanie tot kolacja.` `[TE BEVESTIGEN]`
2. **nabiał** — *zuivel*
   `Twaróg, de witte verse kaas die je op brood smeert of door pierogi mengt. Zure room voor soepen en sauzen, kefir om te drinken. Zuivel is in de Poolse keuken vaak net wat zuurder en voller dan je gewend bent.` `[TE BEVESTIGEN]`
3. **wędliny** — *vleeswaren*
   `Gerookte worst, ham en spek: in Polen is roken een vak. Kiełbasa gaat op brood, in de soep of op de grill, en hoort bij bijna elk feest — van een gewone zondag tot de mand van de święconka.` `[TE BEVESTIGEN]`
4. **spiżarnia** — *voorraadkast*
   `Ogórki kiszone, zuurkool, rode biet, jam en ingemaakte paddenstoelen. De voorraadkast is het hart van een Poolse keuken: alles wat in glas bewaard wordt, smaakt naar thuis.` `[TE BEVESTIGEN]`
5. **słodycze** — *snoep & koek*
   `Chocolade, wafels, peperkoek en snoepjes die je kent uit je jeugd. Zoetigheid is in Polen iets om te delen: bij de koffie, bij bezoek of gewoon na het eten.` `[TE BEVESTIGEN]`
6. **napoje** — *dranken*
   `Van vruchtensap en mineraalwater tot de dranken die bij een Poolse tafel horen. Welke dranken Warta verkoopt, vullen we aan zodra de winkel het bevestigt.` `[TE BEVESTIGEN]`

Bijschrift bij elke uitsnede: `Sfeerbeeld`

## Interactief — Mijn boodschappenlijst / Moja lista
- Chip: `moja lista · mijn lijst`
- **H2:** `maak je eigen lijstje.`
- Tekst: `Tik op een groep en hij valt in de mand. Kopieer je lijst, print hem uit of bel de winkel om te vragen of alles er is. Geen bestelling, geen account — gewoon een lijstje voor onderweg.`
- Lege staat: `je mand is nog leeg. tik op een groep.`
- Teller: `{n} in je mand`
- Knoppen: `Kopieer lijst` · `Print lijst` · `Begin opnieuw` · `Bel om te checken` (→ tel)
- Toast na kopiëren: `Lijst gekopieerd.`
- Kopregel van de geprinte/gekopieerde lijst: `Mijn boodschappenlijst — Warta Supermarkt, Stationsstraat 126, Waalwijk`
- Voetnoot: `Productgroepen zijn voorbeelden en nog niet bevestigd door de winkel.`

## Interactief — słowo / woord
- Chip: `słowo · woord`
- **H3:** `tik en vertaal.`
- Tekst: `Een klein Pools woordenboekje voor in de winkel. Tik op een woord en zie de Nederlandse betekenis.`
- Kaartjes (voorkant PL → achterkant NL + uitspraakhint):
  - `chleb` → `brood` · *chlep*
  - `słoik` → `pot, glazen pot` · *swojik*
  - `twaróg` → `verse witte kaas` · *tvaroek*
  - `ogórki kiszone` → `gegiste augurken` · *ogoerki kisjone*
  - `kiełbasa` → `worst` · *kjeuwbasa*
  - `nabiał` → `zuivel` · *nabjauw*
  - `smacznego` → `eet smakelijk` · *smatsjnego*
  - `dziękuję` → `dank je wel` · *dzjenkoeje*
- Voetnoot: `Uitspraak is een benadering voor Nederlandse lezers.`

## Placeholder-blok (stippelrand)
- **H3:** `hier komen de echte schappen.`
- Tekst: `Op deze plek komen foto's van de echte schappen van Warta. De beelden op deze pagina zijn sfeerbeelden en laten niet het actuele assortiment zien.`
- Label: `[FOTO'S WINKEL TE BEVESTIGEN]`

## Finale (gedeeld) — zie Home finale.

---

# OVER ONS (`over-ons.html`)

## Hero
- Chip: `o nas · over ons`
- **H1:** `een rivier, een winkel.`
- Lead: `Warta is een rivier in Polen. In Waalwijk is het ook een supermarkt — aan de Stationsstraat, voor iedereen die Polen mist of wil leren kennen.`
- Bijschrift: `Sfeerbeeld`

## Sectie «naam» (tekst kleurt bij scrollen)
- Chip: `nazwa · de naam`
- Kleurregel (groot, Sora 300): `warta. → rzeka. → sklep w waalwijk.`
- **H2:** `waarom warta.`

Elke naam vertelt iets. Warta is de naam van een rivier die dwars door het westen van Polen stroomt, en voor veel mensen is het een woord dat meteen een beeld oproept: water, wilgen, mist in de ochtend, het landschap van thuis. Door een winkel zo te noemen, neem je dat beeld mee naar een andere plek.

Die plek is Waalwijk. Een Brabantse stad met een eigen karakter. Een Poolse supermarkt aan de Stationsstraat maakt daar gewoon deel van uit: een plek waar twee keukens en twee talen elkaar gewoon tegenkomen.

- Beeld F12, bijschrift: `Sfeerbeeld`

## Sectie «waarom» — waar we voor willen staan
- Chip: `dlaczego · waarom`
- **H2:** `drie dingen die tellen.`
- Intro: `Geen lange geschiedenis, geen grote woorden. Gewoon drie dingen waar een goede buurtwinkel om draait.`

1. **dichtbij.** — *blisko*
   `Een winkel die je kunt binnenlopen zonder plan. In een gewone straat, op loopafstand van je dag. Even een brood halen, even kijken, even iets vragen.`
2. **twee talen.** — *dwa języki*
   `Nederlands en Pools naast elkaar, te beginnen op deze website. Voor wie al jaren hier woont, voor wie net is aangekomen en voor de nieuwsgierige buurman.`
3. **zoals thuis.** — *jak w domu*
   `Vertrouwde smaken die je niet hoeft uit te leggen. Het soort boodschappen waarmee een gewone dag gewoon goed begint.`

## Lijn-proces (SVG, rode stip rijdt mee)
- Chip: `droga · de weg`
- **H2:** `van de rivier naar je deur.`
- Stap 1 — `rzeka` · **de rivier.** `Het begint bij een naam en een landschap: de Warta, ergens in Polen.`
- Stap 2 — `droga` · **de weg.** `Smaken en gewoontes reizen mee met de mensen die ze kennen.`
- Stap 3 — `drzwi` · **de deur.** `En komen aan in Waalwijk, aan de Stationsstraat 126. Gewoon om de hoek.`

## Finale (gedeeld) — zie Home finale.

---

# CONTACT (`contact.html`)

## Hero
- Chip: `kontakt · contact`
- **H1:** `kom gewoon langs.`
- Lead: `Warta Supermarkt, Stationsstraat 126 in Waalwijk. Bel gerust vooraf als je wilt weten of iets er is, of plan je route en loop binnen.`
- Knoppen: `Bel 0416 203 437` (accent) · `Route plannen` (contour)
- Bijschrift: `Sfeerbeeld`

## Glazen raster
| Label (chip) | Waarde | Subregel | Actie |
|---|---|---|---|
| `adres` | `Stationsstraat 126` | `5141 GH Waalwijk` | `Route plannen` |
| `telefoon` | `0416 203 437` | `+31 416 203 437` | `Bel nu` → `tel:+31416203437` |
| `openingstijden` | `[OPENINGSTIJDEN TE BEVESTIGEN]` | `bel bij twijfel even vooraf` | — |
| `facebook` | `Warta Supermarkt Waalwijk` | `nieuws en updates` | `Open Facebook` |

## Kaart (SVG-schema)
- Chip: `mapa · kaart`
- **H2:** `hier vind je ons.`
- Tekst: `Stationsstraat 126, 5141 GH Waalwijk. Open de kaart voor de snelste route vanaf waar je nu bent.`
- Label bij rode stip: `warta.`
- Knop: `Open in Google Maps`
- Voetnoot: `Schematische kaart, niet op schaal.`

## Korte tekst onder het raster
- **H3:** `liever even bellen?`
- `Bel 0416 203 437 en vraag het gewoon. In het Nederlands of in het Pools? [TE BEVESTIGEN]`

## Finale (gedeeld) — zie Home finale.

---

# 404 (optioneel)
- Chip: `ups · oeps`
- **H1:** `deze mand is leeg.`
- Tekst: `Deze pagina bestaat niet. Ga terug naar home of bel 0416 203 437.`
- Knop: `Terug naar home`

---

# PL-KERNTEKSTEN (voor de schakelaar `PL`)
Zelfde regels: kleine letters, punt aan het eind, placeholders in het Pools: `[DO POTWIERDZENIA]`, `[GODZINY OTWARCIA DO POTWIERDZENIA]`.

- Banner: `Projekt poglądowy — ITty Company`
- Nav: `Start` · `Asortyment` · `O nas` · `Kontakt` · pil: `Zadzwoń: 0416 203 437`
- Tabbalk hero: `Chleb · Spiżarnia · Świeże · Kontakt`
- Teller: `koszyk · 1 / 8`

### Home
- Hero — chip `Polski supermarket · Waalwijk` · **H1** `polskie smaki, za rogiem.` · lead `Warta Supermarkt przy Stationsstraat w Waalwijk. Kawałek Polski dla tych, którzy tęsknią — i odkrycie dla ciekawych polskiej kuchni.` · plaatjes `Stationsstraat 126 — 5141 GH Waalwijk` / `0416 203 437 — zadzwoń` / `NL · PL — strona w dwóch językach`
- Gl.1 — chip `rzeka` · **H2** `nazwany na cześć rzeki.` · `Warta to jedna z największych rzek Polski. Sklep, który nosi jej imię, nie obiecuje wielkich rzeczy — obiecuje coś bliższego: znajome uczucie, tu, w Waalwijk.` · plaatje `Warta — rzeka w Polsce`
- Gl.2 — chip `lniany ręcznik` · **H2** `jak w domu, tylko tutaj.` · `Koszyk na ręce, lniana ściereczka na chlebie. Sklep, w którym nazwy brzmią znajomo i nie trzeba niczego tłumaczyć. Czy w sklepie obsługa mówi po polsku? [DO POTWIERDZENIA]`
- Gl.3 — chip `chleb` · **H2** `wszystko zaczyna się od chleba.` · `Ciemny chleb żytni na zakwasie, na śniadanie i na kolację. Jaki chleb jest w Warcie? [DO POTWIERDZENIA]`
- Gl.4 — chip `słoik` · **H2** `smak pełnej spiżarni.` · `Ogórki kiszone, konfitury, kapusta kiszona — smak babcinej spiżarni. Jakie przetwory są w sklepie? [DO POTWIERDZENIA]`
- Gl.5 — chip `na stół` · **H2** `razem przy jednym stole.` · `Niedzielny obiad, Wigilia, Wielkanoc i święconka. Wędliny i nabiał w Warcie: [DO POTWIERDZENIA]`
- Gl.6 — chip `pełny koszyk` · **H2** `jeden koszyk, dużo domu.` · lijst `chleb i wypieki · nabiał · wędliny · spiżarnia · słodycze · napoje` (elk `[DO POTWIERDZENIA]`) · knop `Zobacz asortyment`
- Gl.7 — chip `za rogiem` · **H2** `po prostu za rogiem.` · `Stationsstraat 126, 5141 GH Waalwijk. Godziny otwarcia: [GODZINY OTWARCIA DO POTWIERDZENIA]` · knoppen `Wyznacz trasę` · `Zadzwoń`
- Finale — chip `do zobaczenia` · **H2** `do zobaczenia, za rogiem.` · `Stationsstraat 126, Waalwijk — zadzwoń 0416 203 437 albo po prostu wpadnij.`

### Asortyment
- chip `Grupy produktów — do potwierdzenia` · **H1** `półka pełna domu.` · lead `Od chleba po spiżarnię: grupy produktów, bez których nie obejdzie się polska kuchnia. Dokładny asortyment Warty potwierdzimy ze sklepem.`
- Lint-H2 `sześć słów polskiej kuchni.` · lijst-H2 `zrób własną listę.` · lege staat `twój koszyk jest jeszcze pusty.` · placeholder-H3 `tu pojawią się prawdziwe półki.`

### O nas
- chip `o nas` · **H1** `rzeka i sklep.` · `naam`-H2 `dlaczego warta.` · `waarom`-H2 `trzy rzeczy, które się liczą.` (`blisko.` · `dwa języki.` · `jak w domu.`) · lijn-H2 `od rzeki do twoich drzwi.`

### Kontakt
- chip `kontakt` · **H1** `po prostu wpadnij.` · raster: `adres` / `telefon` / `godziny otwarcia: [GODZINY OTWARCIA DO POTWIERDZENIA]` / `facebook` · kaart-H2 `tu nas znajdziesz.` · voetnoot `Mapa schematyczna, nie w skali.`

### Footer PL
`Polski supermarket w Waalwijk.` · `Projekt poglądowy ITty Company. Zdjęcia mają charakter poglądowy.` · `do zobaczenia — tot ziens.`

---

## Open punten voor de klant (niet op de site)
Openingstijden · bevestigde productgroepen (vervangt alle `[TE BEVESTIGEN]` bij brood/zuivel/vleeswaren/voorraadkast/snoep/dranken) · of er Pools/Nederlands gesproken wordt · echte foto's van schappen en gevel.
